# Ece Arman — servis başlangıç sürümü

21 Eylül 2026. Canlıya alınmadı. Slack kimliği kurulmuş, Socket Mode ve dört olay aboneliği açık olarak doğrulanmıştır. Görünen ad Ece Arman olarak kaydedildi.

## Bu paketin kapsamı

- Kaan'ın izinli dört kanaldaki mesajlarına veya Ece'ye doğrudan mesajlarına kendi bot tokenı ile thread cevabı.
- Pazartesi-cumartesi İstanbul 10.00 öncelik taslağı, 18.00 yönetim raporu taslağı; zamanlayıcı varsayılan kapalı.
- SQLite üzerinde gelen istek, cevap, gönderim durumu ve günlük çağrı sayacı.
- Aynı mesajın message/app_mention çift teslimini tekilleştirme; botlardan ve başka kullanıcılardan tetiklenmeme.
- Dış işlem araçları bulunmaz. Site güncelleme, otomatik görev atama/CRUD, departman yöneticileri ve araştırma henüz bu sürümde yoktur. Bunlar tamamlanmış gibi sunulmaz.

## Devreye alma — kalan işler

1. Railway ve OpenAI Developers bağlantıları; uygun hesap erişimi, model ve bütçenin belirlenmesi.
2. Tek sürekli worker, /data kalıcı disk; herkese açık domain/HTTP endpoint gerekmiyor. Mevcut özel operasyon sitesinin görünürlüğü değişmez.
3. Slack xoxb, xapp ve OpenAI anahtarlarını yalnızca servisin güvenli secret alanına koy. Sohbete, dosyaya veya kaynak koduna yazma. Bu pakette anahtar yoktur.
4. Ece'yi operasyon-merkezi, gunluk-raporlar, ceo-onay, departman-destek özel kanallarına ekle ve bot kullanıcı kimliğini doğrula. Bu üyelikler henüz doğrulanmadı.
5. Bağımlılıkları gerçek ortamda kur, sürümleri kilitle; ağ/API entegrasyon testi yap. Burada yalnızca yerel politika ve kuyruk testleri çalıştırıldı.
6. ECE_ENABLED=true, SCHEDULE_ENABLED=false ile Kaan'ın tek test mesajını yanıtla. Gönderenin Ece olduğunu, doğru thread ve bildirimi kanıtla. Bot döngüsü ve tekrar olay testini yap.
7. Eski Kaan adına yazan Ece otomasyonlarını karşılaştırıp çakışmayı gider. Sonra SCHEDULE_ENABLED=true; sabah ve akşam uçtan uca testi. Bu paket eski otomasyonları değiştirmez.
8. Site senkronizasyonu için ayrıca ortak görev deposu gerekir. Site şu an localStorage kullanıyor; bu paket o veriyi okuyamaz.

## İşletim sınırları

Geçmiş son 30 ana mesaj ve servisin kaydettiği konuşmalarla sınırlıdır; eski thread geçmişi tam değildir. Eksik bağlam cevapta belirtilir. Dosya/ek okunmaz. Kalıcı disk yoksa geçmiş kaybolur. Tek replica gerekir. Başarısız veya sonucu belirsiz gönderimler needs_review/sending/prepared durumunda durur, otomatik tekrar gönderilmez; yönetici incelemesi gerekir. Slack onayı ile SQLite kaydı atomik değildir, tam exactly-once garantisi verilmez. Servis kapalıyken kaçan vardiyalar sonradan otomatik gönderilmez. SDK olay onayı ile yerel kuyruk kaydı arasında küçük kayıp aralığı vardır. Üretim öncesi kurtarma ve alarm mekanizması geliştirilmelidir.

Günlük çağrı sınırı para cinsinden harcama garantisi değildir; sağlayıcı tarafında bütçe kontrolü ayrıca ayarlanmalıdır. Model bilerek seçilmemiştir. Ücretsiz veya sabaha hazır çalışma taahhüdü yoktur.

## Doğrulama

`python -m unittest -v test_core.py`

Kaynaklar:
- https://docs.slack.dev/tools/bolt-python/concepts/socket-mode/
- https://developers.openai.com/api/docs/quickstart
- https://docs.railway.com/volumes/reference
