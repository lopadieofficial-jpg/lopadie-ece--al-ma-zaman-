"""Pure policy and durable queue; no network or credentials at import time."""
import json
import sqlite3
from datetime import datetime
from zoneinfo import ZoneInfo

KAAN = 'U0C31EU2ULV'
TEAM = 'T0C40NM35DE'
OPERATIONS = 'C0C36ANFXQS'
REPORTS = 'C0C2R2EJJ79'
APPROVALS = 'C0C36A6CHR8'
SUPPORT = 'C0C36ASERD0'
CHANNELS = {OPERATIONS, REPORTS, APPROVALS, SUPPORT}
TZ = ZoneInfo('Europe/Istanbul')

def accepted(body):
    e = body.get('event', {})
    return (body.get('team_id') == TEAM and e.get('user') == KAAN
            and not e.get('bot_id') and not e.get('subtype')
            and e.get('type') in {'message', 'app_mention'}
            and (e.get('channel') in CHANNELS or e.get('channel_type') == 'im')
            and isinstance(e.get('ts'), str) and bool(e.get('text', '').strip()))

def event_key(e):
    # An app_mention and message event can represent the same message.
    return e['channel'] + ':' + e['ts']

def schedule(now):
    now = now.astimezone(TZ)
    if now.weekday() == 6:
        return None
    if (now.hour, now.minute) == (10, 0):
        return ('morning:' + now.date().isoformat(), OPERATIONS, 'morning')
    if (now.hour, now.minute) == (18, 0):
        return ('evening:' + now.date().isoformat(), REPORTS, 'evening')
    return None

class Store:
    def __init__(self, path):
        self.path = path
        with self.db() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, payload TEXT, state TEXT, output TEXT, error TEXT, created TEXT)')

    def db(self):
        return sqlite3.connect(self.path, timeout=20)

    def enqueue(self, key, payload):
        with self.db() as db:
            return db.execute("INSERT OR IGNORE INTO jobs VALUES (?,?,'pending',NULL,NULL,?)", (key, json.dumps(payload, ensure_ascii=False), datetime.now(TZ).isoformat())).rowcount == 1

    def next(self):
        with self.db() as db:
            row = db.execute("SELECT id,payload,output FROM jobs WHERE state='pending' ORDER BY created LIMIT 1").fetchone()
        return (row[0], json.loads(row[1]), row[2]) if row else None

    def state(self, key, state, output=None, error=None):
        with self.db() as db:
            db.execute('UPDATE jobs SET state=?,output=COALESCE(?,output),error=? WHERE id=?', (state, output, error, key))

    def recent(self):
        with self.db() as db:
            rows = db.execute('SELECT id,payload,state,output FROM jobs ORDER BY created DESC LIMIT 30').fetchall()
        return [{'id':r[0], 'request':json.loads(r[1]), 'delivery_state':r[2], 'reply':r[3]} for r in reversed(rows)]
